import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, Concatenate

def build_base_model_1(input_shape):
    """
    Build the first base model (e.g., a simple deep neural network).
    """
    inputs = Input(shape=input_shape)
    x = Dense(64, activation='relu')(inputs)
    x = Dropout(0.2)(x)
    x = Dense(32, activation='relu')(x)
    outputs = Dense(16, activation='relu')(x)
    model = Model(inputs=inputs, outputs=outputs, name="base_model_1")
    return model

def build_base_model_2(input_shape):
    """
    Build the second base model (e.g., a deeper neural network).
    """
    inputs = Input(shape=input_shape)
    x = Dense(128, activation='relu')(inputs)
    x = Dropout(0.3)(x)
    x = Dense(64, activation='relu')(x)
    outputs = Dense(16, activation='relu')(x)
    model = Model(inputs=inputs, outputs=outputs, name="base_model_2")
    return model

def build_stacked_model(input_shape):
    """
    Build the stacked ensemble model by combining two base models.
    """
    # Define input layer
    inputs = Input(shape=input_shape)
    
    # Build base models
    base1 = build_base_model_1(input_shape)
    base2 = build_base_model_2(input_shape)
    
    # Get outputs from both base models
    out1 = base1(inputs)
    out2 = base2(inputs)
    
    # Concatenate outputs of the base models
    concatenated = Concatenate()([out1, out2])
    
    # Add additional dense layers for stacking
    x = Dense(32, activation='relu')(concatenated)
    x = Dropout(0.2)(x)
    # Final output layer for binary classification
    final_output = Dense(1, activation='sigmoid')(x)
    
    # Create and compile the model
    model = Model(inputs=inputs, outputs=final_output, name="stacked_model")
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    
    return model

if __name__ == '__main__':
    # Example usage:
    # The input shape is 6 since there are 6 features in the preprocessed data.
    dummy_input_shape = (6,)
    model = build_stacked_model(dummy_input_shape)
    model.summary()
